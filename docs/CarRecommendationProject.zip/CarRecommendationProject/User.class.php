<?php
// Define the User class
class User {
    public $username;
    public $password;
    
    function __construct($username, $password) {
        $this->username = $username;
        $this->password = $password;
    }
    
    // Method to verify password
    public function verifyPassword($password) {
        return $this->password === $password;
    }
}
?>