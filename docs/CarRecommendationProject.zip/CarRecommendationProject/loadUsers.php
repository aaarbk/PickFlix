<?php
require_once 'User.class.php';
// Define the global array to store User objects
$users = array();

// Sample existing users
$users[] = new User('user1', '321');
$users[] = new User('user2', '123');
$users[] = new User('tom', '123');
$users[] = new User('hafeez', '123');

$users[] = new User('jassim', '123');
// Add more users as needed

?>