<?php
session_start();

// Check if the user is authenticated, if not then redirect to login.php page.
if (! isset($_SESSION['user_id'])) {
    echo "session ID not set";
    // Wait for 5 seconds
    sleep(5);
    header('Location: Main.php');
    exit();
}

// Check if session is not timed out i.e., check if current time is greater than session timeout
if (isset($_SESSION['timeout']) && time() > $_SESSION['timeout']) {
    echo "Session timed out!";
    // Wait for 5 seconds
    // sleep(5);
    session_destroy();
    header('Location: Main.php');
    exit();
}

// Update session timeout on user activity
$_SESSION['timeout'] = time() + (30 * 60);

// Display secure content

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Car Recommendation System</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <!-- Custom CSS -->
    <style>
        /* Style for header */
        .header {
            background-color: #343a40; /* Bootstrap dark background color */
            color: #ffffff; /* Bootstrap light text color */
            padding: 20px;
            text-align: center;
        }
        /* Style for user icon */
        .user-icon {
            position: absolute;
            top: 10px;
            right: 20px;
        }
        /* Style for menu */
        .menu {
            position: fixed;
            top: 95px; /* Adjust based on header height */
            right: 0;
            padding: 20px;
            background-color: #f8f9fa; /* Bootstrap light gray background color */
            border-left: 1px solid #dee2e6; /* Bootstrap border color */
            height: calc(100vh - 70px); /* Adjust based on header height */
            width: 20%; /* Set width for menu */
            z-index: 1000; /* Ensure it's above other content */
        }
        /* Style for menu items */
        .menu-item {
            margin-bottom: 25px;
        }
        /* Style for content area */
        .content {
            margin-right: 22%; /* Adjust based on menu width */
            padding: 20px;
        }
<!-- Example Table Style -->
    table {
        width: 100%;
        border-collapse: collapse;
    }
    th, td {
        border: 1px solid #dddddd;
        text-align: left;
        padding: 8px;
    }
    th {
        background-color: #f2f2f2;
    }
    </style>
</head>
<body>

<!-- Header -->
<div class="header">
    <h1>Car Recommendation System</h1>
    <!-- User icon -->
    <div class="user-icon">
        <img src=<?php

        echo $_SESSION['username'] . ".png";
        ?> alt="User Icon" width="60" height="60">
        <!-- Replace "user-icon.png" with the path to your user icon image -->
    <div class="username"><?php

    echo $_SESSION['username'];
    ?></div>
    <!-- Replace "XX" with the actual username -->
    </div>
</div>

<div class="container-fluid">
    <div class="row">
        <!-- Content area -->
        <div class="col-lg-9 offset-lg-3 content">
            <!-- Content goes here -->
            <h2>Welcome to Car Recommendation System</h2>
            <p>This is the content area where specific page content will be displayed.</p>
<br>
<h2>You are logged in as <?php

echo $_SESSION['username'];
?></h2>
<h4>This is your reviews page...</h4>

<div style="max-width: 600px;">
    <h2>2018 Toyota Camry Sedan Review</h2>
    <p>The <strong>2018 Toyota Camry</strong> is a well-rounded midsize sedan known for its reliability, fuel efficiency, and comfortable ride. With just <strong>30,000 miles</strong> and priced at <strong>$20,000</strong>, it offers great value, especially considering Toyota’s reputation for longevity.</p>
    <p>Its <strong>2.5L 4-cylinder engine</strong> delivers a smooth and efficient driving experience, while the spacious interior and intuitive infotainment system enhance comfort. Advanced safety features like <strong>Toyota Safety Sense-P</strong> add to its appeal, making it an excellent choice for commuters and families alike.</p>
    <p>Overall, this Camry remains a <strong>smart, dependable, and cost-effective</strong> option in the used car market.</p>
</div>
<br>

        </div>
        <!-- Menu -->
        <div class="col-lg-3 menu">
            <h5><a href="master.php">Menu</a></h5>
            <ul class="list-unstyled">
                <li class="menu-item"><a href="cars.php">Cars</a></li>
                <li class="menu-item"><a href="reviews.php">User Reviews</a></li>
                <li class="menu-item"><a href="#">Recommendations</a></li>
                <li class="menu-item"><a href="#">Favorite Cars</a></li>
                <li class="menu-item"><a href="#">Save as Favorite</a></li>
                <li class="menu-item"><a href="#">External Reviews</a></li>
                <li class="menu-item"><a href="logout.php">Logout</a></li>
            </ul>
        </div>
    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>
</html>
