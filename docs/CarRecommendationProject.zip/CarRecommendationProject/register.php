<?php
require_once 'loadUsers.php';

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve username and password from the form
    $new_username = $_POST['username'];
    $new_password = $_POST['password'];

    // Check if the username is not already taken
    $username_exists = false;
    foreach ($users as $user) {
        if ($user->username === $new_username) {
            $username_exists = true;
            break;
        }
    }

    if (! $username_exists) {
        // Create a new User object
        $new_user = new User($new_username, $new_password);
        // Add the new user to the users array
        $users[] = $new_user;
        // Display success message
        echo "<h3>User registration successful!</h3>";
        echo "<p>Welcome, $new_username! You can now login with your credentials.</p>";
        sleep(3);
        // Route to Main.html page for log in.
        header('Location: Main.php');
    } else {
        // Display error message if username is already taken
        echo "<h3>Error: Username already exists!</h3>";
        echo "<p>Please choose a different username.</p>";
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Car Recommendation System - Register</title>
  <!-- Bootstrap CSS -->
  <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
  <!-- Custom styles -->
  <style>
    body {
      background-color: #f8f9fa;
    }
    .register-container {
      max-width: 400px;
      margin: auto;
      margin-top: 100px;
      padding: 20px;
      background-color: #fff;
      border-radius: 5px;
      box-shadow: 0px 0px 10px 0px rgba(0,0,0,0.1);
    }
    .register-header {
      text-align: center;
      margin-bottom: 20px;
    }
  </style>
</head>
<body>

<div class="container">
  <div class="register-container">
    <h2 class="register-header">Register</h2>
    <form action="<?php

    echo htmlspecialchars($_SERVER["PHP_SELF"]);
    ?>" method="post">
      <div class="form-group">
        <label for="username">Username</label>
        <input type="text" class="form-control" id="username" name="username" placeholder="Enter username" required>
      </div>
      <div class="form-group">
        <label for="password">Password</label>
        <input type="password" class="form-control" id="password" name="password" placeholder="Password" required>
      </div>
      <button type="submit" class="btn btn-primary btn-block">Register</button>
    </form>
    <div class="text-center mt-3">
      <a href="Main.php">Already have an account? Login here</a>
    </div>
  </div>
</div>

<!-- Bootstrap JS and dependencies -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
