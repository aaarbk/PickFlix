module.exports = {
    php: "/Applications/xampp/xamppfiles/bin/php"
  }